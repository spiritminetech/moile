/**
 * Test script for Notification API integration
 * Run with: node test-notification-api.js
 */

const axios = require('axios');

// Configuration
const BASE_URL = 'http://localhost:3000'; // Update with your backend URL
const TEST_TOKEN = 'your-jwt-token-here'; // Update with valid JWT token

// Test data
const testNotificationId = 1;
const testDeviceData = {
  token: 'ExponentPushToken[test-token-123]',
  platform: 'ios',
  deviceId: 'test-device-123',
  userId: 1
};

// API client setup
const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Authorization': `Bearer ${TEST_TOKEN}`,
    'Content-Type': 'application/json'
  }
});

// Test functions
async function testGetNotifications() {
  console.log('\n🔍 Testing GET /api/notifications...');
  try {
    const response = await apiClient.get('/api/notifications', {
      params: {
        limit: 10,
        offset: 0,
        status: 'PENDING'
      }
    });
    
    console.log('✅ GET /api/notifications - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ GET /api/notifications - FAILED');
    console.log('Error:', error.response?.data || error.message);
    return null;
  }
}

async function testMarkAsRead(notificationId) {
  console.log(`\n📖 Testing PUT /api/notifications/${notificationId}/read...`);
  try {
    const response = await apiClient.put(`/api/notifications/${notificationId}/read`);
    
    console.log('✅ PUT /api/notifications/:id/read - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ PUT /api/notifications/:id/read - FAILED');
    console.log('Error:', error.response?.data || error.message);
    return null;
  }
}

async function testMarkAllAsRead() {
  console.log('\n📚 Testing POST /api/notifications/read-all...');
  try {
    const response = await apiClient.post('/api/notifications/read-all');
    
    console.log('✅ POST /api/notifications/read-all - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ POST /api/notifications/read-all - FAILED');
    console.log('Error:', error.response?.data || error.message);
    console.log('Note: This endpoint may not be implemented yet on the backend');
    return null;
  }
}

async function testDeleteNotification(notificationId) {
  console.log(`\n🗑️ Testing DELETE /api/notifications/${notificationId}...`);
  try {
    const response = await apiClient.delete(`/api/notifications/${notificationId}`);
    
    console.log('✅ DELETE /api/notifications/:id - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ DELETE /api/notifications/:id - FAILED');
    console.log('Error:', error.response?.data || error.message);
    console.log('Note: This endpoint may not be implemented yet on the backend');
    return null;
  }
}

async function testRegisterDevice() {
  console.log('\n📱 Testing POST /api/notifications/register-device...');
  try {
    const response = await apiClient.post('/api/notifications/register-device', testDeviceData);
    
    console.log('✅ POST /api/notifications/register-device - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ POST /api/notifications/register-device - FAILED');
    console.log('Error:', error.response?.data || error.message);
    return null;
  }
}

async function testNotificationHistory() {
  console.log('\n📜 Testing GET /api/notifications/history...');
  try {
    const response = await apiClient.get('/api/notifications/history', {
      params: {
        limit: 5,
        offset: 0
      }
    });
    
    console.log('✅ GET /api/notifications/history - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ GET /api/notifications/history - FAILED');
    console.log('Error:', error.response?.data || error.message);
    return null;
  }
}

async function testNotificationStats() {
  console.log('\n📊 Testing GET /api/notifications/stats...');
  try {
    const response = await apiClient.get('/api/notifications/stats');
    
    console.log('✅ GET /api/notifications/stats - SUCCESS');
    console.log('Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.log('❌ GET /api/notifications/stats - FAILED');
    console.log('Error:', error.response?.data || error.message);
    return null;
  }
}

// Main test runner
async function runAllTests() {
  console.log('🚀 Starting Notification API Integration Tests');
  console.log('='.repeat(50));
  
  // Test basic functionality
  const notifications = await testGetNotifications();
  
  if (notifications && notifications.notifications && notifications.notifications.length > 0) {
    const firstNotificationId = notifications.notifications[0].id;
    await testMarkAsRead(firstNotificationId);
  } else {
    console.log('\n⚠️ No notifications found, testing with default ID:', testNotificationId);
    await testMarkAsRead(testNotificationId);
  }
  
  // Test bulk operations (may not be implemented)
  await testMarkAllAsRead();
  
  // Test deletion (may not be implemented)
  if (notifications && notifications.notifications && notifications.notifications.length > 1) {
    const secondNotificationId = notifications.notifications[1].id;
    await testDeleteNotification(secondNotificationId);
  } else {
    await testDeleteNotification(testNotificationId);
  }
  
  // Test additional endpoints
  await testRegisterDevice();
  await testNotificationHistory();
  await testNotificationStats();
  
  console.log('\n' + '='.repeat(50));
  console.log('🏁 Notification API Integration Tests Complete');
  console.log('\n📋 Summary:');
  console.log('✅ Implemented: GET /api/notifications, PUT /api/notifications/:id/read');
  console.log('❌ May need implementation: POST /api/notifications/read-all, DELETE /api/notifications/:id');
  console.log('🔧 Additional endpoints: register-device, history, stats');
}

// Error handling for the script
process.on('unhandledRejection', (error) => {
  console.error('❌ Unhandled promise rejection:', error);
  process.exit(1);
});

// Run tests if this file is executed directly
if (require.main === module) {
  if (!TEST_TOKEN || TEST_TOKEN === 'your-jwt-token-here') {
    console.log('⚠️ Please update the TEST_TOKEN variable with a valid JWT token');
    console.log('You can get a token by logging in through the mobile app or API');
    process.exit(1);
  }
  
  runAllTests().catch(error => {
    console.error('❌ Test execution failed:', error);
    process.exit(1);
  });
}

module.exports = {
  testGetNotifications,
  testMarkAsRead,
  testMarkAllAsRead,
  testDeleteNotification,
  testRegisterDevice,
  testNotificationHistory,
  testNotificationStats
};