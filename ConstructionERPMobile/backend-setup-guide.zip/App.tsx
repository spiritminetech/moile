import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// ✅ Use named exports only
import { AuthProvider, useAuth } from './src/store/context/AuthContext';
import { NotificationProvider, useNotifications } from './src/store/context/NotificationContext';
import AppNavigator from './src/navigation/AppNavigator';

// Main App
const App: React.FC = () => {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <NotificationProvider>
          <AppContent />
          <StatusBar style="auto" />
        </NotificationProvider>
      </AuthProvider>
    </SafeAreaProvider>
  );
};

// App content that consumes auth state
const AppContent: React.FC = () => {
  const { state } = useAuth();

  // Debug: see auth state in console
  console.log('Auth State:', {
    isAuthenticated: state.isAuthenticated,
    userRole: state.user?.role || state.company?.role,
    isLoading: state.isLoading,
  });

  return (
    <AppNavigator
      isAuthenticated={state.isAuthenticated}
      userRole={state.user?.role || state.company?.role}
    />
  );
};

export default App;
