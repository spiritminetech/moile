// Camera services exports

export { default as CameraService, cameraService } from './CameraService';
export type { CameraOptions, ImagePickerResponse } from './CameraService';