export { default as NotificationService } from './NotificationService';
export type { PushNotificationToken, NotificationPermissionStatus } from './NotificationService';