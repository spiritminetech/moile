import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Notification, NotificationType } from '../../types';
import { notificationApiService } from '../api/NotificationApiService';

// Configure notification behavior - moved to NotificationProvider useEffect

export interface PushNotificationToken {
  token: string;
  type: 'expo' | 'fcm' | 'apns';
}

export interface NotificationPermissionStatus {
  granted: boolean;
  canAskAgain: boolean;
  status: string; // Changed from Notifications.PermissionStatus to avoid static import
}

export class NotificationService {
  private static instance: NotificationService;
  private pushToken: string | null = null;
  private notificationListener: any | null = null; // Changed from Notifications.Subscription
  private responseListener: any | null = null; // Changed from Notifications.Subscription

  private constructor() {}

  public static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  /**
   * Initialize notification service and request permissions
   * ✅ CRITICAL FIX: Lazy-load expo-notifications to prevent SDK 53 crashes
   */
  public async initialize(): Promise<boolean> {
    try {
      // Check if device supports push notifications
      if (!Device.isDevice) {
        console.warn('Push notifications only work on physical devices');
        return false;
      }

      // Request permissions
      const permissionStatus = await this.requestPermissions();
      if (!permissionStatus.granted) {
        console.warn('Notification permissions not granted');
        return false;
      }

      // Get push token
      const token = await this.registerForPushNotifications();
      if (!token) {
        console.warn('Failed to get push notification token');
        return false;
      }

      this.pushToken = token;
      await this.storePushToken(token);

      // Set up notification listeners
      this.setupNotificationListeners();

      console.log('Notification service initialized successfully');
      return true;
    } catch (error) {
      console.error('Failed to initialize notification service:', error);
      return false;
    }
  }

  /**
   * Request notification permissions from user
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  public async requestPermissions(): Promise<NotificationPermissionStatus> {
    try {
      // ✅ Destructure exports directly from dynamic import
      const { getPermissionsAsync, requestPermissionsAsync } = await import('expo-notifications');
      
      const { status: existingStatus } = await getPermissionsAsync();
      let finalStatus = existingStatus;

      if (existingStatus !== 'granted') {
        const { status } = await requestPermissionsAsync();
        finalStatus = status;
      }

      return {
        granted: finalStatus === 'granted',
        canAskAgain: finalStatus === 'undetermined',
        status: finalStatus,
      };
    } catch (error) {
      console.error('Error requesting notification permissions:', error);
      return {
        granted: false,
        canAskAgain: false,
        status: 'denied',
      };
    }
  }

  /**
   * Register device for push notifications and get token
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  private async registerForPushNotifications(): Promise<string | null> {
    try {
      // ✅ Destructure exports directly from dynamic import
      const { setNotificationChannelAsync, AndroidImportance, getExpoPushTokenAsync } = await import('expo-notifications');
      
      let token: string;

      if (Platform.OS === 'android') {
        await setNotificationChannelAsync('default', {
          name: 'default',
          importance: AndroidImportance.MAX,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#FF231F7C',
        });

        // Create notification channels for different types
        await this.createNotificationChannels();
      }

      const tokenData = await getExpoPushTokenAsync({
        projectId: Constants.expoConfig?.extra?.eas?.projectId,
      });

      token = tokenData.data;
      console.log('Push notification token:', token);

      return token;
    } catch (error) {
      console.error('Error getting push notification token:', error);
      return null;
    }
  }

  /**
   * Create notification channels for Android
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  private async createNotificationChannels(): Promise<void> {
    if (Platform.OS !== 'android') return;

    try {
      // ✅ Destructure exports directly from dynamic import
      const { setNotificationChannelAsync, AndroidImportance } = await import('expo-notifications');
      
      const channels = [
        {
          id: 'task_updates',
          name: 'Task Updates',
          importance: AndroidImportance.HIGH,
          description: 'Notifications about task assignments and updates',
        },
        {
          id: 'site_changes',
          name: 'Site Changes',
          importance: AndroidImportance.HIGH,
          description: 'Notifications about site location or schedule changes',
        },
        {
          id: 'attendance_alerts',
          name: 'Attendance Alerts',
          importance: AndroidImportance.MAX,
          description: 'Important attendance-related notifications',
        },
        {
          id: 'request_status',
          name: 'Request Status',
          importance: AndroidImportance.DEFAULT,
          description: 'Updates on leave, material, and other requests',
        },
        {
          id: 'safety_incidents',
          name: 'Safety Incidents',
          importance: AndroidImportance.MAX,
          description: 'Critical safety incident notifications',
          vibrationPattern: [0, 500, 250, 500],
          lightColor: '#FF0000',
        },
      ];

      for (const channel of channels) {
        await setNotificationChannelAsync(channel.id, channel);
      }
    } catch (error) {
      console.error('Error creating notification channels:', error);
    }
  }

  /**
   * Set up notification event listeners
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  private setupNotificationListeners(): void {
    const setupListeners = async () => {
      try {
        const {
          addNotificationReceivedListener,
          addNotificationResponseReceivedListener,
        } = await import('expo-notifications');

        this.notificationListener = addNotificationReceivedListener(
          this.handleNotificationReceived.bind(this)
        );

        this.responseListener = addNotificationResponseReceivedListener(
          this.handleNotificationResponse.bind(this)
        );
      } catch (error) {
        console.error('Error setting up notification listeners:', error);
      }
    };

    setupListeners();
  }

  /**
   * Handle notification received while app is in foreground
   */
  private handleNotificationReceived(notification: any): void {
    console.log('Notification received:', notification);
    
    const notificationData = this.parseNotificationData(notification);
    if (notificationData) {
      // Emit event for app components to handle
      this.emitNotificationEvent('notificationReceived', notificationData);
    }
  }

  /**
   * Handle user tapping on notification
   */
  private handleNotificationResponse(response: any): void {
    console.log('Notification response:', response);
    
    const notificationData = this.parseNotificationData(response.notification);
    if (notificationData) {
      // Emit event for navigation handling
      this.emitNotificationEvent('notificationTapped', {
        ...notificationData,
        actionIdentifier: response.actionIdentifier,
      });
    }
  }

  /**
   * Parse notification data from Expo notification format
   */
  private parseNotificationData(notification: any): Notification | null {
    try {
      const { request } = notification;
      const { content, identifier } = request;
      const data = content.data as any;

      return {
        id: parseInt(data.id || identifier),
        userId: parseInt(data.userId || '0'),
        title: content.title || '',
        message: content.body || '',
        type: (data.type as NotificationType) || 'task_update',
        priority: data.priority || 'medium',
        createdAt: new Date(data.createdAt || Date.now()),
        readAt: undefined,
        actionRequired: data.actionRequired === 'true' || data.actionRequired === true,
        relatedEntityId: data.relatedEntityId ? parseInt(data.relatedEntityId) : undefined,
        relatedEntityType: data.relatedEntityType,
      };
    } catch (error) {
      console.error('Error parsing notification data:', error);
      return null;
    }
  }

  /**
   * Emit notification events for app components
   */
  private emitNotificationEvent(eventType: string, data: any): void {
    // In a real app, you might use EventEmitter or a state management solution
    // For now, we'll store the event data for components to access
    const eventData = {
      type: eventType,
      data,
      timestamp: new Date(),
    };
    
    // Store latest notification event
    AsyncStorage.setItem('latestNotificationEvent', JSON.stringify(eventData));
  }

  /**
   * Get the current push notification token
   */
  public getPushToken(): string | null {
    return this.pushToken;
  }

  /**
   * Store push token in local storage
   */
  private async storePushToken(token: string): Promise<void> {
    try {
      await AsyncStorage.setItem('pushNotificationToken', token);
    } catch (error) {
      console.error('Error storing push token:', error);
    }
  }

  /**
   * Get stored push token from local storage
   */
  public async getStoredPushToken(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem('pushNotificationToken');
    } catch (error) {
      console.error('Error getting stored push token:', error);
      return null;
    }
  }

  /**
   * Send push token to backend server
   */
  public async registerTokenWithBackend(token: string, userId: number): Promise<boolean> {
    try {
      const response = await notificationApiService.registerDevice({
        token,
        userId,
        platform: Platform.OS,
        deviceId: Constants.deviceId || 'unknown',
      });
      
      if (response.data.success) {
        console.log('Push token registered successfully with backend');
        return true;
      } else {
        console.error('Failed to register push token:', response.data.message);
        return false;
      }
    } catch (error) {
      console.error('Error registering token with backend:', error);
      return false;
    }
  }

  /**
   * Schedule a local notification
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  public async scheduleLocalNotification(
    title: string,
    body: string,
    data?: any,
    trigger?: any
  ): Promise<string | null> {
    try {
      // ✅ Destructure exports directly from dynamic import
      const { scheduleNotificationAsync } = await import('expo-notifications');
      
      const notificationId = await scheduleNotificationAsync({
        content: {
          title,
          body,
          data: data || {},
          sound: true,
        },
        trigger: trigger || null,
      });

      return notificationId;
    } catch (error) {
      console.error('Error scheduling local notification:', error);
      return null;
    }
  }

  /**
   * Cancel a scheduled notification
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  public async cancelNotification(notificationId: string): Promise<void> {
    try {
      // ✅ Destructure exports directly from dynamic import
      const { cancelScheduledNotificationAsync } = await import('expo-notifications');
      await cancelScheduledNotificationAsync(notificationId);
    } catch (error) {
      console.error('Error canceling notification:', error);
    }
  }

  /**
   * Cancel all scheduled notifications
   * ✅ CRITICAL FIX: Destructure exports directly to avoid Hermes issues
   */
  public async cancelAllNotifications(): Promise<void> {
    try {
      // ✅ Destructure exports directly from dynamic import
      const { cancelAllScheduledNotificationsAsync } = await import('expo-notifications');
      await cancelAllScheduledNotificationsAsync();
    } catch (error) {
      console.error('Error canceling all notifications:', error);
    }
  }

  /**
   * Get notification channel for type
   */
  public getChannelIdForType(type: NotificationType): string {
    const channelMap: Record<NotificationType, string> = {
      task_update: 'task_updates',
      site_change: 'site_changes',
      attendance_alert: 'attendance_alerts',
      request_status: 'request_status',
      safety_incident: 'safety_incidents',
    };

    return channelMap[type] || 'default';
  }

  /**
   * Schedule certification expiry reminder notifications
   */
  public async scheduleCertificationExpiryReminders(
    certifications: Array<{
      id: number;
      name: string;
      expiryDate: string;
      daysUntilExpiry: number;
    }>
  ): Promise<void> {
    try {
      // Cancel existing certification reminders
      await this.cancelCertificationReminders();

      for (const cert of certifications) {
        const expiryDate = new Date(cert.expiryDate);
        const now = new Date();

        // Schedule reminders at different intervals
        const reminderIntervals = [
          { days: 30, title: '30 Day Reminder', priority: 'medium' },
          { days: 14, title: '2 Week Reminder', priority: 'high' },
          { days: 7, title: '1 Week Reminder', priority: 'high' },
          { days: 3, title: '3 Day Reminder', priority: 'urgent' },
          { days: 1, title: '1 Day Reminder', priority: 'urgent' },
        ];

        for (const interval of reminderIntervals) {
          const reminderDate = new Date(expiryDate);
          reminderDate.setDate(reminderDate.getDate() - interval.days);

          // Only schedule if reminder date is in the future
          if (reminderDate > now) {
            const notificationId = await this.scheduleLocalNotification(
              `🏆 ${interval.title}: ${cert.name}`,
              `Your ${cert.name} certification expires on ${expiryDate.toLocaleDateString()}. Please plan for renewal.`,
              {
                type: 'certification_expiry',
                certificationId: cert.id,
                certificationName: cert.name,
                expiryDate: cert.expiryDate,
                reminderType: interval.days,
                priority: interval.priority,
              },
              {
                date: reminderDate,
              } as any
            );

            if (notificationId) {
              // Store notification ID for later cancellation
              await this.storeCertificationReminderId(cert.id, interval.days, notificationId);
            }
          }
        }

        // Schedule expiry day notification
        if (expiryDate > now) {
          const expiryNotificationId = await this.scheduleLocalNotification(
            `❌ Certification Expired: ${cert.name}`,
            `Your ${cert.name} certification has expired today. Contact your supervisor immediately.`,
            {
              type: 'certification_expired',
              certificationId: cert.id,
              certificationName: cert.name,
              expiryDate: cert.expiryDate,
              priority: 'urgent',
            },
            {
              date: expiryDate,
            } as any
          );

          if (expiryNotificationId) {
            await this.storeCertificationReminderId(cert.id, 0, expiryNotificationId);
          }
        }
      }

      console.log('Certification expiry reminders scheduled successfully');
    } catch (error) {
      console.error('Error scheduling certification expiry reminders:', error);
    }
  }

  /**
   * Cancel all certification reminder notifications
   */
  public async cancelCertificationReminders(): Promise<void> {
    try {
      const reminderIds = await this.getCertificationReminderIds();
      
      for (const notificationId of reminderIds) {
        await this.cancelNotification(notificationId);
      }

      // Clear stored reminder IDs
      await AsyncStorage.removeItem('certificationReminderIds');
      
      console.log('Certification reminders canceled successfully');
    } catch (error) {
      console.error('Error canceling certification reminders:', error);
    }
  }

  /**
   * Store certification reminder notification ID
   */
  private async storeCertificationReminderId(
    certificationId: number,
    reminderDays: number,
    notificationId: string
  ): Promise<void> {
    try {
      const existingIds = await this.getCertificationReminderIds();
      const newId = `cert_${certificationId}_${reminderDays}_${notificationId}`;
      
      existingIds.push(newId);
      
      await AsyncStorage.setItem('certificationReminderIds', JSON.stringify(existingIds));
    } catch (error) {
      console.error('Error storing certification reminder ID:', error);
    }
  }

  /**
   * Get stored certification reminder notification IDs
   */
  private async getCertificationReminderIds(): Promise<string[]> {
    try {
      const storedIds = await AsyncStorage.getItem('certificationReminderIds');
      return storedIds ? JSON.parse(storedIds) : [];
    } catch (error) {
      console.error('Error getting certification reminder IDs:', error);
      return [];
    }
  }

  /**
   * Check and schedule certification reminders based on current data
   */
  public async updateCertificationReminders(
    certifications: Array<{
      id: number;
      name: string;
      expiryDate: string;
      status: 'active' | 'expired' | 'expiring_soon';
    }>
  ): Promise<void> {
    try {
      // Filter active certifications that need reminders
      const activeCertifications = certifications
        .filter(cert => cert.status === 'active' || cert.status === 'expiring_soon')
        .map(cert => {
          const expiryDate = new Date(cert.expiryDate);
          const now = new Date();
          const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          return {
            id: cert.id,
            name: cert.name,
            expiryDate: cert.expiryDate,
            daysUntilExpiry,
          };
        })
        .filter(cert => cert.daysUntilExpiry > 0 && cert.daysUntilExpiry <= 30); // Only schedule for next 30 days

      await this.scheduleCertificationExpiryReminders(activeCertifications);
    } catch (error) {
      console.error('Error updating certification reminders:', error);
    }
  }
  public cleanup(): void {
    if (this.notificationListener) {
      this.notificationListener.remove();
      this.notificationListener = null;
    }

    if (this.responseListener) {
      this.responseListener.remove();
      this.responseListener = null;
    }
  }

  /**
   * Get latest notification event
   */
  public async getLatestNotificationEvent(): Promise<any | null> {
    try {
      const eventData = await AsyncStorage.getItem('latestNotificationEvent');
      return eventData ? JSON.parse(eventData) : null;
    } catch (error) {
      console.error('Error getting latest notification event:', error);
      return null;
    }
  }

  /**
   * Clear latest notification event
   */
  public async clearLatestNotificationEvent(): Promise<void> {
    try {
      await AsyncStorage.removeItem('latestNotificationEvent');
    } catch (error) {
      console.error('Error clearing latest notification event:', error);
    }
  }
}

export default NotificationService;