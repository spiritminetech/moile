import { apiClient } from './client';
import { ApiResponse } from '../../types';

export interface NotificationResponse {
  id: number;
  type: string;
  priority: string;
  title: string;
  message: string;
  status: string;
  recipientId: number;
  senderId: number;
  createdAt: string;
  readAt: string | null;
  acknowledgedAt: string | null;
  requiresAcknowledgment: boolean;
  actionData: object | null;
  expiresAt: string | null;
}

export interface NotificationsListResponse {
  success: true;
  notifications: NotificationResponse[];
  pagination: {
    total: number;
    limit: number;
    offset: number;
    hasMore: boolean;
  };
  permissions: {
    canReadAll: boolean;
    companyId: number | null;
  };
}

export interface NotificationActionResponse {
  success: boolean;
  message: string;
  notification?: {
    id: number;
    status: string;
    readAt: string;
  };
}

export interface GetNotificationsParams {
  status?: string;
  type?: string;
  priority?: string;
  limit?: number;
  offset?: number;
  startDate?: string;
  endDate?: string;
}

export class NotificationApiService {
  /**
   * Get notifications with optional filters
   */
  async getNotifications(params?: GetNotificationsParams): Promise<ApiResponse<NotificationsListResponse>> {
    try {
      const response = await apiClient.get<NotificationsListResponse>('/api/notifications', { params });
      return response;
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error;
    }
  }

  /**
   * Mark a specific notification as read
   */
  async markAsRead(notificationId: number): Promise<ApiResponse<NotificationActionResponse>> {
    try {
      const response = await apiClient.put<NotificationActionResponse>(`/api/notifications/${notificationId}/read`);
      return response;
    } catch (error) {
      console.error('Error marking notification as read:', error);
      throw error;
    }
  }

  /**
   * Mark all notifications as read
   * Note: This endpoint needs to be implemented on the backend
   */
  async markAllAsRead(): Promise<ApiResponse<{ success: boolean; message: string; updatedCount: number }>> {
    try {
      const response = await apiClient.post<{ success: boolean; message: string; updatedCount: number }>('/api/notifications/read-all');
      return response;
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      throw error;
    }
  }

  /**
   * Delete a specific notification
   * Note: This endpoint needs to be implemented on the backend
   */
  async deleteNotification(notificationId: number): Promise<ApiResponse<{ success: boolean; message: string }>> {
    try {
      const response = await apiClient.delete<{ success: boolean; message: string }>(`/api/notifications/${notificationId}`);
      return response;
    } catch (error) {
      console.error('Error deleting notification:', error);
      throw error;
    }
  }

  /**
   * Get notification history with filtering
   */
  async getNotificationHistory(params?: GetNotificationsParams): Promise<ApiResponse<NotificationsListResponse>> {
    try {
      const response = await apiClient.get<NotificationsListResponse>('/api/notifications/history', { params });
      return response;
    } catch (error) {
      console.error('Error fetching notification history:', error);
      throw error;
    }
  }

  /**
   * Acknowledge a critical notification
   */
  async acknowledgeNotification(notificationId: number): Promise<ApiResponse<NotificationActionResponse>> {
    try {
      const response = await apiClient.put<NotificationActionResponse>(`/api/notifications/${notificationId}/acknowledge`);
      return response;
    } catch (error) {
      console.error('Error acknowledging notification:', error);
      throw error;
    }
  }

  /**
   * Get notification statistics
   */
  async getNotificationStats(): Promise<ApiResponse<{
    total: number;
    unread: number;
    byType: Record<string, number>;
    byPriority: Record<string, number>;
  }>> {
    try {
      const response = await apiClient.get<{
        total: number;
        unread: number;
        byType: Record<string, number>;
        byPriority: Record<string, number>;
      }>('/api/notifications/stats');
      return response;
    } catch (error) {
      console.error('Error fetching notification stats:', error);
      throw error;
    }
  }

  /**
   * Sync offline notification status updates
   */
  async syncOfflineStatusUpdates(updates: Array<{
    notificationId: number;
    status: string;
    timestamp: string;
  }>): Promise<ApiResponse<{ success: boolean; synced: number; failed: number }>> {
    try {
      const response = await apiClient.post<{ success: boolean; synced: number; failed: number }>('/api/notifications/sync/status', { updates });
      return response;
    } catch (error) {
      console.error('Error syncing offline status updates:', error);
      throw error;
    }
  }

  /**
   * Register device for push notifications
   */
  async registerDevice(deviceData: {
    token: string;
    platform: string;
    deviceId: string;
    userId: number;
  }): Promise<ApiResponse<{ success: boolean; message: string }>> {
    try {
      const response = await apiClient.post<{ success: boolean; message: string }>('/api/notifications/register-device', deviceData);
      return response;
    } catch (error) {
      console.error('Error registering device for push notifications:', error);
      throw error;
    }
  }
}

export const notificationApiService = new NotificationApiService();
export default notificationApiService;