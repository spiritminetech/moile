// Property-based tests for Authentication Service
// Feature: construction-erp-mobile, Property 1: Authentication Token Management

import * as fc from 'fast-check';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authService } from '../AuthService';
import { apiClient } from '../client';
import { STORAGE_KEYS } from '../../../utils/constants';

// Mock the API client
jest.mock('../client');
const mockApiClient = apiClient as jest.Mocked<typeof apiClient>;

// Mock AsyncStorage
jest.mock('@react-native-async-storage/async-storage');
const mockAsyncStorage = AsyncStorage as jest.Mocked<typeof AsyncStorage>;

describe('Authentication Token Management Property Tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    // Reset AsyncStorage mock
    mockAsyncStorage.multiSet.mockResolvedValue();
    mockAsyncStorage.multiGet.mockResolvedValue([]);
    mockAsyncStorage.multiRemove.mockResolvedValue();
    mockAsyncStorage.getItem.mockResolvedValue(null);
    mockAsyncStorage.setItem.mockResolvedValue();
  });

  /**
   * Property 1: Authentication Token Management
   * **Validates: Requirements 1.1, 1.2, 10.4**
   * 
   * For any valid user credentials, successful authentication should result in 
   * secure JWT token storage and automatic token attachment to all subsequent 
   * authenticated API requests
   */
  it('should store and attach JWT tokens for any valid credentials', async () => {
    await fc.assert(
      fc.asyncProperty(
        // Generate valid login credentials
        fc.record({
          email: fc.emailAddress(),
          password: fc.string({ minLength: 1, maxLength: 100 }),
        }),
        // Generate valid login response
        fc.record({
          user: fc.record({
            id: fc.integer({ min: 1, max: 10000 }),
            employeeId: fc.string({ minLength: 1, maxLength: 20 }),
            name: fc.string({ minLength: 1, maxLength: 100 }),
            email: fc.emailAddress(),
            phone: fc.string({ minLength: 10, maxLength: 15 }),
            role: fc.constantFrom('worker', 'supervisor', 'driver'),
            certifications: fc.array(fc.record({
              id: fc.integer({ min: 1, max: 1000 }),
              name: fc.string({ minLength: 1, maxLength: 50 }),
              issuer: fc.string({ minLength: 1, maxLength: 50 }),
              issueDate: fc.date(),
              expiryDate: fc.date(),
              certificateNumber: fc.string({ minLength: 1, maxLength: 20 }),
              status: fc.constantFrom('active', 'expired', 'expiring_soon'),
            }), { maxLength: 5 }),
            workPass: fc.record({
              id: fc.integer({ min: 1, max: 1000 }),
              passNumber: fc.string({ minLength: 1, maxLength: 20 }),
              issueDate: fc.date(),
              expiryDate: fc.date(),
              status: fc.constantFrom('active', 'expired', 'suspended'),
            }),
          }),
          token: fc.string({ minLength: 100, maxLength: 500 }).filter(s => 
            // Generate JWT-like tokens with 3 parts separated by dots
            s.includes('.') && s.split('.').length >= 3
          ),
          refreshToken: fc.string({ minLength: 50, maxLength: 200 }),
          expiresIn: fc.integer({ min: 300, max: 86400 }), // 5 minutes to 24 hours
        }),
        async (credentials, mockResponse) => {
          // Mock successful API response
          mockApiClient.post.mockResolvedValueOnce({
            success: true,
            data: mockResponse,
            message: 'Login successful',
          });

          // Execute login
          const result = await authService.login(credentials);

          // Verify API was called with correct credentials
          expect(mockApiClient.post).toHaveBeenCalledWith('/auth/login', credentials);

          // Verify response structure
          expect(result).toEqual(mockResponse);

          // Verify secure token storage - should store all auth data
          expect(mockAsyncStorage.multiSet).toHaveBeenCalledWith([
            [STORAGE_KEYS.AUTH_TOKEN, mockResponse.token],
            [STORAGE_KEYS.REFRESH_TOKEN, mockResponse.refreshToken],
            [STORAGE_KEYS.USER_DATA, JSON.stringify(mockResponse.user)],
            [STORAGE_KEYS.TOKEN_EXPIRY, expect.any(String)],
          ]);

          // Verify token expiry calculation is correct
          const storedData = mockAsyncStorage.multiSet.mock.calls[0][0];
          const tokenExpiryCall = storedData.find(([key]) => key === STORAGE_KEYS.TOKEN_EXPIRY);
          expect(tokenExpiryCall).toBeDefined();
          
          const storedExpiry = new Date(tokenExpiryCall![1]);
          const expectedExpiry = new Date(Date.now() + mockResponse.expiresIn * 1000);
          const timeDifference = Math.abs(storedExpiry.getTime() - expectedExpiry.getTime());
          
          // Allow 1 second tolerance for execution time
          expect(timeDifference).toBeLessThan(1000);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should handle token refresh correctly for any valid refresh token', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          refreshToken: fc.string({ minLength: 50, maxLength: 200 }),
          newToken: fc.string({ minLength: 100, maxLength: 500 }).filter(s => 
            s.includes('.') && s.split('.').length >= 3
          ),
          expiresIn: fc.integer({ min: 300, max: 86400 }),
        }),
        async ({ refreshToken, newToken, expiresIn }) => {
          // Mock stored refresh token
          mockAsyncStorage.getItem.mockImplementation((key) => {
            if (key === STORAGE_KEYS.REFRESH_TOKEN) {
              return Promise.resolve(refreshToken);
            }
            return Promise.resolve(null);
          });

          // Mock successful refresh response
          mockApiClient.post.mockResolvedValueOnce({
            success: true,
            data: { token: newToken, expiresIn },
            message: 'Token refreshed',
          });

          // Execute token refresh
          const result = await authService.refreshToken();

          // Verify API was called with refresh token
          expect(mockApiClient.post).toHaveBeenCalledWith('/auth/refresh', {
            refreshToken,
          });

          // Verify response structure
          expect(result).toEqual({ token: newToken, expiresIn });

          // Verify token and expiry were updated in storage
          expect(mockAsyncStorage.multiSet).toHaveBeenCalledWith([
            [STORAGE_KEYS.AUTH_TOKEN, newToken],
            [STORAGE_KEYS.TOKEN_EXPIRY, expect.any(String)],
          ]);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should clear all authentication data on logout for any user state', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          shouldBackendSucceed: fc.boolean(),
          hasStoredData: fc.boolean(),
        }),
        async ({ shouldBackendSucceed, hasStoredData }) => {
          // Mock backend logout response
          if (shouldBackendSucceed) {
            mockApiClient.post.mockResolvedValueOnce({
              success: true,
              data: null,
              message: 'Logged out successfully',
            });
          } else {
            mockApiClient.post.mockRejectedValueOnce(new Error('Backend logout failed'));
          }

          // Execute logout
          await authService.logout();

          // Verify backend logout was attempted
          expect(mockApiClient.post).toHaveBeenCalledWith('/auth/logout');

          // Verify local storage was cleared regardless of backend response
          expect(mockAsyncStorage.multiRemove).toHaveBeenCalledWith([
            STORAGE_KEYS.AUTH_TOKEN,
            STORAGE_KEYS.REFRESH_TOKEN,
            STORAGE_KEYS.USER_DATA,
            STORAGE_KEYS.TOKEN_EXPIRY,
          ]);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should correctly validate authentication state for any stored token data', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          hasToken: fc.boolean(),
          hasExpiry: fc.boolean(),
          isExpired: fc.boolean(),
          shouldRefreshSucceed: fc.boolean(),
        }),
        async ({ hasToken, hasExpiry, isExpired, shouldRefreshSucceed }) => {
          const now = new Date();
          const futureDate = new Date(now.getTime() + 3600000); // 1 hour from now
          const pastDate = new Date(now.getTime() - 3600000); // 1 hour ago
          const expiry = isExpired ? pastDate : futureDate;

          // Mock stored data
          mockAsyncStorage.getItem.mockImplementation((key) => {
            switch (key) {
              case STORAGE_KEYS.AUTH_TOKEN:
                return Promise.resolve(hasToken ? 'valid.jwt.token' : null);
              case STORAGE_KEYS.TOKEN_EXPIRY:
                return Promise.resolve(hasExpiry ? expiry.toISOString() : null);
              case STORAGE_KEYS.REFRESH_TOKEN:
                return Promise.resolve('refresh-token');
              default:
                return Promise.resolve(null);
            }
          });

          // Mock refresh token response if needed
          if (isExpired && shouldRefreshSucceed) {
            mockApiClient.post.mockResolvedValueOnce({
              success: true,
              data: { token: 'new.jwt.token', expiresIn: 3600 },
            });
          } else if (isExpired && !shouldRefreshSucceed) {
            mockApiClient.post.mockRejectedValueOnce(new Error('Refresh failed'));
          }

          // Execute authentication check
          const isAuthenticated = await authService.isAuthenticated();

          // Verify expected behavior
          if (!hasToken || !hasExpiry) {
            expect(isAuthenticated).toBe(false);
          } else if (!isExpired) {
            expect(isAuthenticated).toBe(true);
          } else if (isExpired && shouldRefreshSucceed) {
            expect(isAuthenticated).toBe(true);
            expect(mockApiClient.post).toHaveBeenCalledWith('/auth/refresh', {
              refreshToken: 'refresh-token',
            });
          } else {
            expect(isAuthenticated).toBe(false);
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  /**
   * Property 3: Authentication Error Handling
   * **Validates: Requirements 1.4, 1.5**
   * 
   * For any authentication failure or token expiry, the mobile app should display 
   * the exact error message from the backend system and prompt for re-authentication
   */
  it('should display exact backend error messages for any authentication failure', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          credentials: fc.record({
            email: fc.emailAddress(),
            password: fc.string({ minLength: 1, maxLength: 100 }),
          }),
          errorScenario: fc.constantFrom(
            'invalid_credentials',
            'network_error', 
            'server_error',
            'validation_error',
            'token_expired'
          ),
          backendErrorMessage: fc.string({ minLength: 1, maxLength: 200 }),
          httpStatusCode: fc.integer({ min: 400, max: 599 }),
        }),
        async ({ credentials, errorScenario, backendErrorMessage, httpStatusCode }) => {
          let expectedError: any;
          let shouldThrow = true;

          // Create different error scenarios based on Requirements 1.4 and 1.5
          switch (errorScenario) {
            case 'invalid_credentials':
              // Requirement 1.5: Display specific error message from backend
              expectedError = {
                response: {
                  status: 401,
                  data: { message: backendErrorMessage },
                },
              };
              break;
            
            case 'network_error':
              // Network connectivity issues
              expectedError = new Error('Network Error');
              expectedError.code = 'NETWORK_ERROR';
              break;
            
            case 'server_error':
              // Server-side errors (5xx)
              expectedError = {
                response: {
                  status: httpStatusCode >= 500 ? httpStatusCode : 500,
                  data: { message: backendErrorMessage },
                },
              };
              break;
            
            case 'validation_error':
              // Client-side validation errors (4xx)
              expectedError = {
                response: {
                  status: httpStatusCode >= 400 && httpStatusCode < 500 ? httpStatusCode : 400,
                  data: { message: backendErrorMessage },
                },
              };
              break;
            
            case 'token_expired':
              // Requirement 1.4: Token expiry should prompt re-authentication
              expectedError = {
                response: {
                  status: 401,
                  data: { message: 'Token expired' },
                },
              };
              break;
          }

          // Mock the API client to throw the expected error
          mockApiClient.post.mockRejectedValueOnce(expectedError);

          // Execute login and verify it throws with the correct error
          try {
            await authService.login(credentials);
            // If we reach here, the test should fail because an error was expected
            expect(shouldThrow).toBe(false);
          } catch (thrownError: any) {
            // Verify the error was thrown as expected
            expect(shouldThrow).toBe(true);
            
            // Verify the error contains information that can be used to display
            // the exact backend error message (Requirement 1.5)
            expect(thrownError).toBeDefined();
            expect(thrownError instanceof Error).toBe(true);
          }

          // Verify API was called with correct credentials
          expect(mockApiClient.post).toHaveBeenCalledWith('/auth/login', credentials);

          // Verify no authentication data was stored on error (security requirement)
          expect(mockAsyncStorage.multiSet).not.toHaveBeenCalled();
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should handle token expiry and prompt re-authentication for any expired token scenario', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.record({
          hasToken: fc.boolean(),
          hasRefreshToken: fc.boolean(),
          tokenExpired: fc.boolean(),
          refreshTokenValid: fc.boolean(),
          backendErrorMessage: fc.string({ minLength: 1, maxLength: 200 }),
        }),
        async ({ hasToken, hasRefreshToken, tokenExpired, refreshTokenValid, backendErrorMessage }) => {
          const pastDate = new Date(Date.now() - 3600000); // 1 hour ago
          const futureDate = new Date(Date.now() + 3600000); // 1 hour from now
          
          // Mock stored token data
          mockAsyncStorage.getItem.mockImplementation((key) => {
            switch (key) {
              case STORAGE_KEYS.AUTH_TOKEN:
                return Promise.resolve(hasToken ? 'expired.jwt.token' : null);
              case STORAGE_KEYS.TOKEN_EXPIRY:
                return Promise.resolve(tokenExpired ? pastDate.toISOString() : futureDate.toISOString());
              case STORAGE_KEYS.REFRESH_TOKEN:
                return Promise.resolve(hasRefreshToken ? 'refresh-token' : null);
              default:
                return Promise.resolve(null);
            }
          });

          // Mock refresh token behavior
          if (hasRefreshToken && refreshTokenValid) {
            // Successful refresh
            mockApiClient.post.mockResolvedValueOnce({
              success: true,
              data: { token: 'new.jwt.token', expiresIn: 3600 },
            });
          } else if (hasRefreshToken && !refreshTokenValid) {
            // Failed refresh - should prompt re-authentication (Requirement 1.4)
            mockApiClient.post.mockRejectedValueOnce({
              response: {
                status: 401,
                data: { message: backendErrorMessage },
              },
            });
          }

          // Execute authentication check
          const isAuthenticated = await authService.isAuthenticated();

          // Verify behavior based on token state
          if (!hasToken || !tokenExpired) {
            // No token or token not expired - should return appropriate state
            if (!hasToken) {
              expect(isAuthenticated).toBe(false);
            } else {
              expect(isAuthenticated).toBe(true);
            }
          } else if (tokenExpired && hasRefreshToken && refreshTokenValid) {
            // Expired token with valid refresh - should succeed after refresh
            expect(isAuthenticated).toBe(true);
            expect(mockApiClient.post).toHaveBeenCalledWith('/auth/refresh', {
              refreshToken: 'refresh-token',
            });
          } else if (tokenExpired && (!hasRefreshToken || !refreshTokenValid)) {
            // Expired token without valid refresh - should prompt re-authentication (Requirement 1.4)
            expect(isAuthenticated).toBe(false);
            
            if (hasRefreshToken) {
              // Verify refresh was attempted
              expect(mockApiClient.post).toHaveBeenCalledWith('/auth/refresh', {
                refreshToken: 'refresh-token',
              });
            }
          }
        }
      ),
      { numRuns: 100 }
    );
  });
});