import { apiClient } from './client';
import { ApiResponse, GeoLocation, AttendanceRecord } from '../../types';

export interface GeofenceValidationRequest {
  projectId: string;
  latitude: number;
  longitude: number;
  accuracy?: number;
}

export interface GeofenceValidationResponse {
  insideGeofence: boolean;
  distance: number;
  canProceed: boolean;
  message: string;
  accuracy: number | null;
}

export interface AttendanceSubmitRequest {
  projectId: string;
  session: 'checkin' | 'checkout';
  latitude: number;
  longitude: number;
}

export interface AttendanceSubmitResponse {
  message: string;
}

export interface TodaysAttendanceResponse {
  session: 'NOT_LOGGED_IN' | 'CHECKED_IN' | 'CHECKED_OUT';
  checkInTime: string | null;
  checkOutTime: string | null;
  lunchStartTime: string | null;
  lunchEndTime: string | null;
  overtimeStartTime: string | null;
  date: string;
  projectId?: string;
}

export interface LunchReminderRequest {
  workerId: string;
  projectId: string;
}

export interface LunchReminderResponse {
  success: boolean;
  message: string;
  result: any;
}

export interface OvertimeAlertRequest {
  workerId: string;
  overtimeInfo: any;
  overtimeType: 'START' | 'END';
}

export interface OvertimeAlertResponse {
  success: boolean;
  message: string;
  result: any;
}

export interface LocationLogRequest {
  projectId: string;
  latitude: number;
  longitude: number;
}

export interface LocationLogResponse {
  insideGeofence: boolean;
}

export interface CheckAlertsResponse {
  success: boolean;
  message: string;
  results: any;
}

export interface AttendanceHistoryRecord {
  employeeId: string;
  projectId: string;
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  lunchStartTime: string | null;
  lunchEndTime: string | null;
  overtimeStartTime: string | null;
  insideGeofenceAtCheckin: boolean;
  insideGeofenceAtCheckout: boolean;
  pendingCheckout: boolean;
}

export interface AttendanceHistoryResponse {
  records: AttendanceHistoryRecord[];
}

export class AttendanceApiService {
  /**
   * 1. POST /api/attendance/validate-geofence - Geofence validation
   */
  async validateGeofence(request: GeofenceValidationRequest): Promise<ApiResponse<GeofenceValidationResponse>> {
    return apiClient.post('/api/attendance/validate-geofence', request);
  }

  /**
   * 2. POST /api/attendance/submit - Clock in/out with location
   */
  async submitAttendance(request: AttendanceSubmitRequest): Promise<ApiResponse<AttendanceSubmitResponse>> {
    return apiClient.post('/api/attendance/submit', request);
  }

  /**
   * 3. GET /api/attendance/today - Today's attendance records
   */
  async getTodaysAttendance(): Promise<ApiResponse<TodaysAttendanceResponse>> {
    return apiClient.get('/api/attendance/today');
  }

  /**
   * 4. POST /api/attendance/send-lunch-reminder - Start lunch break
   */
  async sendLunchReminder(request: LunchReminderRequest): Promise<ApiResponse<LunchReminderResponse>> {
    return apiClient.post('/api/attendance/send-lunch-reminder', request);
  }

  /**
   * 5. POST /api/attendance/send-overtime-alert - End lunch break / Overtime alerts
   */
  async sendOvertimeAlert(request: OvertimeAlertRequest): Promise<ApiResponse<OvertimeAlertResponse>> {
    return apiClient.post('/api/attendance/send-overtime-alert', request);
  }

  /**
   * 6. GET /api/attendance/status - Current attendance status
   */
  async getAttendanceStatus(): Promise<ApiResponse<TodaysAttendanceResponse>> {
    return apiClient.get('/api/attendance/status');
  }

  /**
   * 7. GET /api/attendance/history - Attendance history with filtering
   */
  async getAttendanceHistory(projectId?: string): Promise<ApiResponse<AttendanceHistoryResponse>> {
    const params = projectId ? { projectId } : {};
    return apiClient.get('/api/attendance/history', { params });
  }

  /**
   * Additional: POST /api/attendance/log-location - Location logging
   */
  async logLocation(request: LocationLogRequest): Promise<ApiResponse<LocationLogResponse>> {
    return apiClient.post('/api/attendance/log-location', request);
  }

  /**
   * Additional: POST /api/attendance/check-alerts - Check attendance alerts
   */
  async checkAlerts(): Promise<ApiResponse<CheckAlertsResponse>> {
    return apiClient.post('/api/attendance/check-alerts');
  }

  // Convenience methods for easier integration
  async clockIn(projectId: string, location: GeoLocation): Promise<ApiResponse<AttendanceSubmitResponse>> {
    return this.submitAttendance({
      projectId,
      session: 'checkin',
      latitude: location.latitude,
      longitude: location.longitude,
    });
  }

  async clockOut(projectId: string, location: GeoLocation): Promise<ApiResponse<AttendanceSubmitResponse>> {
    return this.submitAttendance({
      projectId,
      session: 'checkout',
      latitude: location.latitude,
      longitude: location.longitude,
    });
  }
}

export const attendanceApiService = new AttendanceApiService();
export default attendanceApiService;