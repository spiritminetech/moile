import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { Notification, NotificationType } from '../../types';

interface NotificationItemProps {
  notification: Notification;
  onPress: (notification: Notification) => void;
  onMarkAsRead: (notificationId: number) => void;
  onRemove: (notificationId: number) => void;
}

const NotificationItem: React.FC<NotificationItemProps> = ({
  notification,
  onPress,
  onMarkAsRead,
  onRemove,
}) => {
  const isUnread = !notification.readAt;

  const handlePress = () => {
    if (isUnread) {
      onMarkAsRead(notification.id);
    }
    onPress(notification);
  };

  const handleLongPress = () => {
    Alert.alert(
      'Notification Options',
      'What would you like to do with this notification?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: isUnread ? 'Mark as Read' : 'Mark as Unread',
          onPress: () => onMarkAsRead(notification.id),
        },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: () => onRemove(notification.id),
        },
      ]
    );
  };

  const getNotificationIcon = (type: NotificationType): string => {
    switch (type) {
      case 'task_update':
        return '📋';
      case 'site_change':
        return '🏗️';
      case 'attendance_alert':
        return '⏰';
      case 'request_status':
        return '📝';
      case 'safety_incident':
        return '⚠️';
      default:
        return '📢';
    }
  };

  const getPriorityColor = (priority: string): string => {
    switch (priority) {
      case 'urgent':
        return '#FF4444';
      case 'high':
        return '#FF8800';
      case 'medium':
        return '#4CAF50';
      case 'low':
        return '#9E9E9E';
      default:
        return '#4CAF50';
    }
  };

  const formatTime = (date: Date): string => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));

    if (diffInMinutes < 1) {
      return 'Just now';
    } else if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else if (diffInMinutes < 1440) {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours}h ago`;
    } else {
      const days = Math.floor(diffInMinutes / 1440);
      return `${days}d ago`;
    }
  };

  return (
    <TouchableOpacity
      style={[
        styles.container,
        isUnread && styles.unreadContainer,
      ]}
      onPress={handlePress}
      onLongPress={handleLongPress}
      activeOpacity={0.7}
    >
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>{getNotificationIcon(notification.type)}</Text>
          {isUnread && <View style={styles.unreadDot} />}
        </View>
        
        <View style={styles.headerText}>
          <Text style={[styles.title, isUnread && styles.unreadTitle]} numberOfLines={1}>
            {notification.title}
          </Text>
          <View style={styles.metaInfo}>
            <View
              style={[
                styles.priorityBadge,
                { backgroundColor: getPriorityColor(notification.priority) },
              ]}
            >
              <Text style={styles.priorityText}>{notification.priority.toUpperCase()}</Text>
            </View>
            <Text style={styles.timeText}>{formatTime(notification.createdAt)}</Text>
          </View>
        </View>
      </View>

      <Text style={[styles.message, isUnread && styles.unreadMessage]} numberOfLines={3}>
        {notification.message}
      </Text>

      {notification.actionRequired && (
        <View style={styles.actionBadge}>
          <Text style={styles.actionText}>Action Required</Text>
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    marginHorizontal: 16,
    marginVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  unreadContainer: {
    backgroundColor: '#F8F9FF',
    borderColor: '#2196F3',
    borderLeftWidth: 4,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  iconContainer: {
    position: 'relative',
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
    width: 40,
    height: 40,
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
  },
  icon: {
    fontSize: 20,
  },
  unreadDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 12,
    height: 12,
    backgroundColor: '#FF4444',
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333333',
    marginBottom: 4,
  },
  unreadTitle: {
    fontWeight: '700',
    color: '#000000',
  },
  metaInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    marginRight: 8,
  },
  priorityText: {
    fontSize: 10,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  timeText: {
    fontSize: 12,
    color: '#666666',
  },
  message: {
    fontSize: 14,
    color: '#666666',
    lineHeight: 20,
    marginBottom: 8,
  },
  unreadMessage: {
    color: '#333333',
    fontWeight: '500',
  },
  actionBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#FF8800',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 4,
  },
  actionText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});

export default NotificationItem;