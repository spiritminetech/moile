import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { Notification, NotificationState } from '../../types';
import { NotificationService } from '../../services/notifications';
import { notificationApiService, NotificationsListResponse } from '../../services/api/NotificationApiService';
import { ApiResponse } from '../../types';

// Initial state
const initialState: NotificationState = {
  notifications: [],
  unreadCount: 0,
  isLoading: false,
  error: null,
};

// Action types
type NotificationAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_NOTIFICATIONS'; payload: Notification[] }
  | { type: 'ADD_NOTIFICATION'; payload: Notification }
  | { type: 'MARK_AS_READ'; payload: number }
  | { type: 'MARK_ALL_AS_READ' }
  | { type: 'REMOVE_NOTIFICATION'; payload: number }
  | { type: 'CLEAR_NOTIFICATIONS' }
  | { type: 'UPDATE_UNREAD_COUNT'; payload: number }
  | { type: 'SET_ERROR'; payload: string | null };

// Reducer
function notificationReducer(state: NotificationState, action: NotificationAction): NotificationState {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_NOTIFICATIONS':
      return {
        ...state,
        notifications: action.payload,
        unreadCount: action.payload.filter(n => !n.readAt).length,
        isLoading: false,
        error: null,
      };
    case 'ADD_NOTIFICATION':
      return {
        ...state,
        notifications: [action.payload, ...state.notifications],
        unreadCount: action.payload.readAt ? state.unreadCount : state.unreadCount + 1,
      };
    case 'MARK_AS_READ':
      return {
        ...state,
        notifications: state.notifications.map(n =>
          n.id === action.payload ? { ...n, readAt: new Date() } : n
        ),
        unreadCount: Math.max(0, state.unreadCount - 1),
      };
    case 'MARK_ALL_AS_READ':
      return {
        ...state,
        notifications: state.notifications.map(n => ({ ...n, readAt: new Date() })),
        unreadCount: 0,
      };
    case 'REMOVE_NOTIFICATION':
      const removedNotification = state.notifications.find(n => n.id === action.payload);
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.payload),
        unreadCount: removedNotification && !removedNotification.readAt
          ? Math.max(0, state.unreadCount - 1)
          : state.unreadCount,
      };
    case 'CLEAR_NOTIFICATIONS':
      return {
        ...state,
        notifications: [],
        unreadCount: 0,
      };
    case 'UPDATE_UNREAD_COUNT':
      return {
        ...state,
        unreadCount: action.payload,
      };
    case 'SET_ERROR':
      return {
        ...state,
        error: action.payload,
        isLoading: false,
      };
    default:
      return state;
  }
}

// Context type
interface NotificationContextType {
  state: NotificationState;
  actions: {
    loadNotifications: () => Promise<void>;
    addNotification: (notification: Notification) => void;
    markAsRead: (notificationId: number) => Promise<void>;
    markAllAsRead: () => Promise<void>;
    removeNotification: (notificationId: number) => Promise<void>;
    clearNotifications: () => Promise<void>;
    initializeNotificationService: () => Promise<boolean>;
    getPushToken: () => string | null;
  };
}

// Context
const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(notificationReducer, initialState);

  // ✅ CRITICAL FIX: Set up notification handler with destructured imports
  useEffect(() => {
    const setupNotificationHandler = async () => {
      try {
        // ✅ Destructure exports directly from dynamic import to avoid Hermes issues
        const { setNotificationHandler } = await import('expo-notifications');
        
        setNotificationHandler({
          handleNotification: async () => ({
            shouldShowAlert: true,
            shouldPlaySound: true,
            shouldSetBadge: false,
            shouldShowBanner: true,
            shouldShowList: true,
          }),
        });
        
        console.log('Notification handler configured successfully');
      } catch (error) {
        console.error('Error setting up notification handler:', error);
      }
    };

    setupNotificationHandler();
  }, []);

  // Initialize NotificationService
  useEffect(() => {
    const initService = async () => {
      try {
        const notificationService = NotificationService.getInstance();
        const initialized = await notificationService.initialize();
        
        if (initialized) {
          console.log('NotificationService initialized successfully');
          // Load initial notifications
          await loadNotifications();
        } else {
          console.warn('NotificationService initialization failed');
        }
      } catch (error) {
        console.error('Error initializing NotificationService:', error);
        dispatch({ type: 'SET_ERROR', payload: 'Failed to initialize notifications' });
      }
    };

    initService();
  }, []);

  const loadNotifications = async () => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      const response: ApiResponse<NotificationsListResponse> = await notificationApiService.getNotifications();
      
      if (response.data.success && response.data.notifications) {
        // Convert API response to internal Notification format
        const notifications: Notification[] = response.data.notifications.map(apiNotification => ({
          id: apiNotification.id,
          userId: apiNotification.recipientId,
          title: apiNotification.title,
          message: apiNotification.message,
          type: apiNotification.type as any, // Cast to NotificationType
          priority: apiNotification.priority as any, // Cast to priority type
          createdAt: new Date(apiNotification.createdAt),
          readAt: apiNotification.readAt ? new Date(apiNotification.readAt) : undefined,
          actionRequired: apiNotification.requiresAcknowledgment,
          relatedEntityId: undefined, // Not provided in API response
          relatedEntityType: undefined, // Not provided in API response
        }));
        
        dispatch({ type: 'SET_NOTIFICATIONS', payload: notifications });
      } else {
        dispatch({ type: 'SET_ERROR', payload: 'Failed to load notifications' });
      }
    } catch (error) {
      console.error('Error loading notifications:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Failed to load notifications' });
    }
  };

  const addNotification = (notification: Notification) => {
    dispatch({ type: 'ADD_NOTIFICATION', payload: notification });
  };

  const markAsRead = async (notificationId: number) => {
    try {
      const response = await notificationApiService.markAsRead(notificationId);
      
      if (response.data.success) {
        dispatch({ type: 'MARK_AS_READ', payload: notificationId });
      } else {
        dispatch({ type: 'SET_ERROR', payload: response.data.message || 'Failed to mark notification as read' });
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Failed to mark notification as read' });
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await notificationApiService.markAllAsRead();
      
      if (response.data.success) {
        dispatch({ type: 'MARK_ALL_AS_READ' });
      } else {
        dispatch({ type: 'SET_ERROR', payload: response.data.message || 'Failed to mark all notifications as read' });
      }
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Failed to mark all notifications as read' });
    }
  };

  const removeNotification = async (notificationId: number) => {
    try {
      const response = await notificationApiService.deleteNotification(notificationId);
      
      if (response.data.success) {
        dispatch({ type: 'REMOVE_NOTIFICATION', payload: notificationId });
      } else {
        dispatch({ type: 'SET_ERROR', payload: response.data.message || 'Failed to remove notification' });
      }
    } catch (error) {
      console.error('Error removing notification:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Failed to remove notification' });
    }
  };

  const clearNotifications = async () => {
    try {
      // Since there's no clearAllNotifications method, we'll just clear locally
      dispatch({ type: 'CLEAR_NOTIFICATIONS' });
    } catch (error) {
      console.error('Error clearing notifications:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Failed to clear notifications' });
    }
  };

  const initializeNotificationService = async (): Promise<boolean> => {
    try {
      const notificationService = NotificationService.getInstance();
      return await notificationService.initialize();
    } catch (error) {
      console.error('Error initializing notification service:', error);
      return false;
    }
  };

  const getPushToken = (): string | null => {
    return NotificationService.getInstance().getPushToken();
  };

  const contextValue: NotificationContextType = {
    state,
    actions: {
      loadNotifications,
      addNotification,
      markAsRead,
      markAllAsRead,
      removeNotification,
      clearNotifications,
      initializeNotificationService,
      getPushToken,
    },
  };

  return (
    <NotificationContext.Provider value={contextValue}>
      {children}
    </NotificationContext.Provider>
  );
};

// Hook
export const useNotifications = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};
