import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { AuthState, User, Company } from '../../types';
import { authService, LoginCredentials } from '../../services/api/AuthService';

// Initial state
const initialAuthState: AuthState = {
  isAuthenticated: false,
  user: null,
  company: null,
  token: null,
  refreshToken: null,
  tokenExpiry: null,
  permissions: [],
  isLoading: false,
  error: null,
  requiresCompanySelection: false,
  availableCompanies: [],
};

// Action types
export type AuthAction =
  | { type: 'LOGIN_START' }
  | { type: 'LOGIN_SUCCESS'; payload: { user: User; company: Company; token: string; refreshToken: string; tokenExpiry: Date; permissions: string[] } }
  | { type: 'LOGIN_FAILURE'; payload: string }
  | { type: 'COMPANY_SELECTION_REQUIRED'; payload: { companies: Company[]; userId: number } }
  | { type: 'LOGOUT' }
  | { type: 'TOKEN_REFRESH'; payload: { token: string; tokenExpiry: Date } }
  | { type: 'UPDATE_USER'; payload: User }
  | { type: 'RESTORE_AUTH'; payload: { user: User; company: Company; token: string; refreshToken: string; tokenExpiry: Date; permissions: string[] } };

// Reducer
const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case 'LOGIN_START':
      return { ...state, isLoading: true, error: null, requiresCompanySelection: false, availableCompanies: [] };
    case 'LOGIN_SUCCESS':
      return { ...state, isAuthenticated: true, ...action.payload, isLoading: false, error: null, requiresCompanySelection: false, availableCompanies: [] };
    case 'LOGIN_FAILURE':
      return { ...state, isAuthenticated: false, user: null, company: null, token: null, refreshToken: null, tokenExpiry: null, permissions: [], isLoading: false, error: action.payload, requiresCompanySelection: false, availableCompanies: [] };
    case 'COMPANY_SELECTION_REQUIRED':
      return { ...state, isLoading: false, error: null, requiresCompanySelection: true, availableCompanies: action.payload.companies };
    case 'LOGOUT':
      return { ...initialAuthState, isLoading: false };
    case 'TOKEN_REFRESH':
      return { ...state, token: action.payload.token, tokenExpiry: action.payload.tokenExpiry };
    case 'UPDATE_USER':
      return { ...state, user: action.payload };
    case 'RESTORE_AUTH':
      return { ...state, isAuthenticated: true, ...action.payload, isLoading: false, error: null, requiresCompanySelection: false, availableCompanies: [] };
    default:
      return state;
  }
};

// Context type
interface AuthContextType {
  state: AuthState;
  dispatch: React.Dispatch<AuthAction>;
  login: (credentials: LoginCredentials) => Promise<void>;
  selectCompany: (companyId: number) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: (token: string, tokenExpiry: Date) => void;
  updateUser: (user: User) => void;
  restoreAuthState: () => Promise<void>;
}

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Provider props
interface AuthProviderProps { children: ReactNode; }

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialAuthState);

  // Restore auth on mount
  useEffect(() => { restoreAuthState(); }, []);

  const login = async (credentials: LoginCredentials) => { /* implement your login logic */ };
  const selectCompany = async (companyId: number) => { /* implement company selection */ };
  const logout = async () => { /* implement logout */ };
  const refreshToken = (token: string, tokenExpiry: Date) => { dispatch({ type: 'TOKEN_REFRESH', payload: { token, tokenExpiry } }); };
  const updateUser = (user: User) => { dispatch({ type: 'UPDATE_USER', payload: user }); };
  const restoreAuthState = async () => { /* implement restore logic */ };

  return <AuthContext.Provider value={{ state, dispatch, login, selectCompany, logout, refreshToken, updateUser, restoreAuthState }}>{children}</AuthContext.Provider>;
};

// Hook
export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
