// Material Request Submission Screen
// Requirements: 6.2

import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  Platform,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';
import { workerApiService } from '../../services/api/WorkerApiService';
import AuthContext from '../../store/context/AuthContext';
import LoadingOverlay from '../../components/common/LoadingOverlay';
import AttachmentManager from '../../components/forms/AttachmentManager';

type Priority = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
type ItemCategory = 'concrete' | 'steel' | 'wood' | 'electrical' | 'plumbing' | 'finishing' | 'hardware' | 'other';

interface PriorityOption {
  value: Priority;
  label: string;
  color: string;
  description: string;
}

interface CategoryOption {
  value: ItemCategory;
  label: string;
  description: string;
}

const PRIORITY_OPTIONS: PriorityOption[] = [
  {
    value: 'LOW',
    label: 'Low',
    color: '#4CAF50',
    description: 'Can wait, not urgent',
  },
  {
    value: 'NORMAL',
    label: 'Normal',
    color: '#FF9800',
    description: 'Standard priority',
  },
  {
    value: 'HIGH',
    label: 'High',
    color: '#F44336',
    description: 'Needed quickly, high priority',
  },
  {
    value: 'URGENT',
    label: 'Urgent',
    color: '#9C27B0',
    description: 'Critical, needed immediately',
  },
];

const CATEGORY_OPTIONS: CategoryOption[] = [
  { value: 'concrete', label: 'Concrete', description: 'Cement, aggregates, concrete blocks' },
  { value: 'steel', label: 'Steel', description: 'Rebar, structural steel, metal sheets' },
  { value: 'wood', label: 'Wood', description: 'Lumber, plywood, timber' },
  { value: 'electrical', label: 'Electrical', description: 'Wires, switches, electrical components' },
  { value: 'plumbing', label: 'Plumbing', description: 'Pipes, fittings, plumbing fixtures' },
  { value: 'finishing', label: 'Finishing', description: 'Paint, tiles, flooring materials' },
  { value: 'hardware', label: 'Hardware', description: 'Screws, bolts, fasteners' },
  { value: 'other', label: 'Other', description: 'Other construction materials' },
];

const COMMON_UNITS = ['pcs', 'kg', 'm', 'm²', 'm³', 'L', 'bags', 'boxes', 'rolls'];

const MaterialRequestScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user } = useContext(AuthContext);
  const [isLoading, setIsLoading] = useState(false);
  
  // Form state
  const [itemName, setItemName] = useState('');
  const [itemCategory, setItemCategory] = useState<ItemCategory>('concrete');
  const [quantity, setQuantity] = useState(1);
  const [unit, setUnit] = useState('pcs');
  const [urgency, setUrgency] = useState<Priority>('NORMAL');
  const [requiredDate, setRequiredDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow;
  });
  const [purpose, setPurpose] = useState('');
  const [justification, setJustification] = useState('');
  const [specifications, setSpecifications] = useState('');
  const [estimatedCost, setEstimatedCost] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [attachments, setAttachments] = useState<File[]>([]);

  // Form validation
  const [errors, setErrors] = useState<{[key: string]: string}>({});

  const validateForm = (): boolean => {
    const newErrors: {[key: string]: string} = {};

    if (!itemName.trim()) {
      newErrors.itemName = 'Item name is required';
    }

    if (!purpose.trim()) {
      newErrors.purpose = 'Purpose is required';
    }

    if (!justification.trim()) {
      newErrors.justification = 'Justification is required';
    }

    if (quantity <= 0 || !Number.isInteger(quantity)) {
      newErrors.quantity = 'Quantity must be a positive whole number';
    }

    if (requiredDate <= new Date()) {
      newErrors.requiredDate = 'Required date must be in the future';
    }

    const costNum = parseFloat(estimatedCost);
    if (estimatedCost.trim() && (isNaN(costNum) || costNum < 0)) {
      newErrors.estimatedCost = 'Estimated cost must be a valid positive number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) {
      return;
    }

    if (!user?.projectId) {
      Alert.alert('Error', 'Project information not available. Please try again.');
      return;
    }

    setIsLoading(true);
    try {
      const response = await workerApiService.submitMaterialRequest({
        projectId: user.projectId,
        itemName: itemName.trim(),
        itemCategory,
        quantity,
        unit,
        urgency,
        requiredDate,
        purpose: purpose.trim(),
        justification: justification.trim(),
        specifications: specifications.trim() || undefined,
        estimatedCost: estimatedCost.trim() ? parseFloat(estimatedCost) : undefined,
        attachments: attachments.length > 0 ? attachments : undefined,
      });

      if (response.success) {
        Alert.alert(
          'Request Submitted',
          response.data.message || 'Your material request has been submitted successfully.',
          [
            {
              text: 'OK',
              onPress: () => navigation.goBack(),
            },
          ]
        );
      } else {
        Alert.alert('Error', response.message || 'Failed to submit material request');
      }
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to submit material request');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDateChange = (event: any, selectedDate?: Date) => {
    setShowDatePicker(false);
    if (selectedDate) {
      setRequiredDate(selectedDate);
    }
  };

  const addMaterialItem = () => {
    const newId = (materials.length + 1).toString();
    setMaterials([...materials, { id: newId, name: '', quantity: 1, unit: 'pcs', specifications: '' }]);
  };

  const removeMaterialItem = (id: string) => {
    if (materials.length > 1) {
      setMaterials(materials.filter(m => m.id !== id));
    }
  };

  const updateMaterialItem = (id: string, field: keyof MaterialItem, value: string | number) => {
    setMaterials(materials.map(m => 
      m.id === id ? { ...m, [field]: value } : m
    ));
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (isLoading) {
    return <LoadingOverlay visible={true} message="Submitting material request..." />;
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Material Request</Text>
          <Text style={styles.headerSubtitle}>
            Request construction materials and supplies
          </Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          {/* Title */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Request Title *</Text>
            <TextInput
              style={[styles.input, errors.title && styles.inputError]}
              value={title}
              onChangeText={setTitle}
              placeholder="e.g., Concrete blocks for foundation work"
              placeholderTextColor="#9E9E9E"
              maxLength={100}
            />
            {errors.title && <Text style={styles.errorText}>{errors.title}</Text>}
          </View>

          {/* Priority */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Priority *</Text>
            <View style={styles.priorityContainer}>
              {PRIORITY_OPTIONS.map((option) => (
                <TouchableOpacity
                  key={option.value}
                  style={[
                    styles.priorityOption,
                    priority === option.value && styles.priorityOptionSelected,
                    { borderLeftColor: option.color },
                  ]}
                  onPress={() => setPriority(option.value)}
                >
                  <View style={styles.priorityHeader}>
                    <Text
                      style={[
                        styles.priorityLabel,
                        priority === option.value && styles.priorityLabelSelected,
                      ]}
                    >
                      {option.label}
                    </Text>
                    <View
                      style={[
                        styles.radioButton,
                        priority === option.value && styles.radioButtonSelected,
                      ]}
                    >
                      {priority === option.value && <View style={styles.radioButtonInner} />}
                    </View>
                  </View>
                  <Text
                    style={[
                      styles.priorityDescription,
                      priority === option.value && styles.priorityDescriptionSelected,
                    ]}
                  >
                    {option.description}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Required Date */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Required Date *</Text>
            <TouchableOpacity
              style={[styles.dateButton, errors.requiredDate && styles.inputError]}
              onPress={() => setShowDatePicker(true)}
            >
              <Text style={styles.dateButtonText}>{formatDate(requiredDate)}</Text>
            </TouchableOpacity>
            {errors.requiredDate && <Text style={styles.errorText}>{errors.requiredDate}</Text>}
          </View>

          {/* Material Items */}
          <View style={styles.inputGroup}>
            <View style={styles.materialsHeader}>
              <Text style={styles.label}>Material Items *</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={addMaterialItem}
              >
                <Text style={styles.addButtonText}>+ Add Item</Text>
              </TouchableOpacity>
            </View>

            {materials.map((material, index) => (
              <View key={material.id} style={styles.materialItem}>
                <View style={styles.materialItemHeader}>
                  <Text style={styles.materialItemTitle}>Item {index + 1}</Text>
                  {materials.length > 1 && (
                    <TouchableOpacity
                      style={styles.removeButton}
                      onPress={() => removeMaterialItem(material.id)}
                    >
                      <Text style={styles.removeButtonText}>Remove</Text>
                    </TouchableOpacity>
                  )}
                </View>

                <TextInput
                  style={styles.input}
                  value={material.name}
                  onChangeText={(value) => updateMaterialItem(material.id, 'name', value)}
                  placeholder="Material name (e.g., Concrete blocks)"
                  placeholderTextColor="#9E9E9E"
                  maxLength={100}
                />

                <View style={styles.quantityRow}>
                  <View style={styles.quantityInput}>
                    <Text style={styles.quantityLabel}>Quantity</Text>
                    <TextInput
                      style={styles.input}
                      value={material.quantity.toString()}
                      onChangeText={(value) => {
                        const num = parseInt(value) || 1;
                        updateMaterialItem(material.id, 'quantity', Math.max(1, num));
                      }}
                      keyboardType="numeric"
                      placeholder="1"
                    />
                  </View>

                  <View style={styles.unitInput}>
                    <Text style={styles.quantityLabel}>Unit</Text>
                    <View style={styles.unitSelector}>
                      <TextInput
                        style={styles.input}
                        value={material.unit}
                        onChangeText={(value) => updateMaterialItem(material.id, 'unit', value)}
                        placeholder="Unit"
                      />
                    </View>
                  </View>
                </View>

                <TextInput
                  style={styles.textArea}
                  value={material.specifications}
                  onChangeText={(value) => updateMaterialItem(material.id, 'specifications', value)}
                  placeholder="Specifications (optional) - size, grade, brand, etc."
                  placeholderTextColor="#9E9E9E"
                  multiline
                  numberOfLines={2}
                  textAlignVertical="top"
                  maxLength={200}
                />
              </View>
            ))}

            {errors.materials && <Text style={styles.errorText}>{errors.materials}</Text>}
            {errors.quantities && <Text style={styles.errorText}>{errors.quantities}</Text>}
          </View>

          {/* Description */}
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Additional Details *</Text>
            <TextInput
              style={[styles.textArea, errors.description && styles.inputError]}
              value={description}
              onChangeText={setDescription}
              placeholder="Provide additional details about your material request, including purpose, location where materials will be used, and any special requirements..."
              placeholderTextColor="#9E9E9E"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              maxLength={500}
            />
            {errors.description && <Text style={styles.errorText}>{errors.description}</Text>}
            <Text style={styles.characterCount}>{description.length}/500</Text>
          </View>
        </View>

        {/* Submit Button */}
        <View style={styles.submitContainer}>
          <TouchableOpacity
            style={[
              styles.submitButton,
              (!title.trim() || !description.trim() || !materials.some(m => m.name.trim())) && styles.submitButtonDisabled
            ]}
            onPress={handleSubmit}
            disabled={!title.trim() || !description.trim() || !materials.some(m => m.name.trim())}
          >
            <Text style={styles.submitButtonText}>Submit Material Request</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Date Picker */}
      {showDatePicker && (
        <DateTimePicker
          value={requiredDate}
          mode="date"
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={handleDateChange}
          minimumDate={new Date()}
        />
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  content: {
    flex: 1,
  },
  header: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#757575',
  },
  form: {
    padding: 16,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212121',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    color: '#212121',
  },
  inputError: {
    borderColor: '#F44336',
  },
  textArea: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    color: '#212121',
    minHeight: 80,
  },
  errorText: {
    fontSize: 14,
    color: '#F44336',
    marginTop: 4,
  },
  characterCount: {
    fontSize: 12,
    color: '#9E9E9E',
    textAlign: 'right',
    marginTop: 4,
  },
  priorityContainer: {
    gap: 8,
  },
  priorityOption: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    borderLeftWidth: 4,
    padding: 16,
  },
  priorityOptionSelected: {
    borderColor: '#2196F3',
    backgroundColor: '#E3F2FD',
  },
  priorityHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  priorityLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212121',
  },
  priorityLabelSelected: {
    color: '#2196F3',
  },
  priorityDescription: {
    fontSize: 14,
    color: '#757575',
  },
  priorityDescriptionSelected: {
    color: '#1976D2',
  },
  radioButton: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  radioButtonSelected: {
    borderColor: '#2196F3',
  },
  radioButtonInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#2196F3',
  },
  dateButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
  },
  dateButtonText: {
    fontSize: 16,
    color: '#212121',
    fontWeight: '500',
  },
  materialsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  addButton: {
    backgroundColor: '#2196F3',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  addButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  materialItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  materialItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  materialItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212121',
  },
  removeButton: {
    backgroundColor: '#F44336',
    borderRadius: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  removeButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  quantityRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
    marginBottom: 12,
  },
  quantityInput: {
    flex: 1,
  },
  unitInput: {
    flex: 1,
  },
  quantityLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#757575',
    marginBottom: 4,
  },
  unitSelector: {
    position: 'relative',
  },
  submitContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  submitButton: {
    backgroundColor: '#2196F3',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  submitButtonDisabled: {
    backgroundColor: '#BDBDBD',
    elevation: 0,
    shadowOpacity: 0,
  },
  submitButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});

export default MaterialRequestScreen;