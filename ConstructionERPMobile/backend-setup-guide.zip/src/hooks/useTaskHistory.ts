import { useState, useEffect, useCallback, useRef } from 'react';
import { workerApiService } from '../services/api/WorkerApiService';
import { TaskAssignment } from '../types';

export interface UseTaskHistoryReturn {
  tasks: TaskAssignment[];
  filteredTasks: TaskAssignment[];
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
  lastRefresh: Date | null;
  isRefreshing: boolean;
  filterTasks: (filter: 'all' | 'completed' | 'in_progress' | 'cancelled') => void;
  currentFilter: 'all' | 'completed' | 'in_progress' | 'cancelled';
}

export const useTaskHistory = (): UseTaskHistoryReturn => {
  const [tasks, setTasks] = useState<TaskAssignment[]>([]);
  const [filteredTasks, setFilteredTasks] = useState<TaskAssignment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [currentFilter, setCurrentFilter] = useState<'all' | 'completed' | 'in_progress' | 'cancelled'>('all');

  const refreshData = useCallback(async (isManualRefresh = false) => {
    try {
      if (isManualRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      const response = await workerApiService.getTaskHistory();
      
      if (response.success) {
        // Sort tasks by completion date or last updated date (most recent first)
        const sortedTasks = response.data.sort((a, b) => {
          const dateA = new Date(a.completedAt || a.updatedAt || a.createdAt);
          const dateB = new Date(b.completedAt || b.updatedAt || b.createdAt);
          return dateB.getTime() - dateA.getTime();
        });
        
        setTasks(sortedTasks);
        setLastRefresh(new Date());
        
        // Apply current filter to new data
        applyFilter(sortedTasks, currentFilter);
      } else {
        setError(response.message || 'Failed to load task history');
      }
    } catch (err: any) {
      setError(err.message || 'Network error occurred');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [currentFilter]);

  const applyFilter = useCallback((taskList: TaskAssignment[], filter: string) => {
    let filtered = taskList;
    
    switch (filter) {
      case 'completed':
        filtered = taskList.filter(task => task.status === 'completed');
        break;
      case 'in_progress':
        filtered = taskList.filter(task => task.status === 'in_progress');
        break;
      case 'cancelled':
        filtered = taskList.filter(task => task.status === 'cancelled');
        break;
      case 'all':
      default:
        filtered = taskList;
        break;
    }
    
    setFilteredTasks(filtered);
  }, []);

  const filterTasks = useCallback((filter: 'all' | 'completed' | 'in_progress' | 'cancelled') => {
    setCurrentFilter(filter);
    applyFilter(tasks, filter);
  }, [tasks, applyFilter]);

  const handleManualRefresh = useCallback(async () => {
    await refreshData(true);
  }, [refreshData]);

  // Initial data load
  useEffect(() => {
    refreshData();
  }, [refreshData]);

  return {
    tasks,
    filteredTasks,
    isLoading,
    error,
    refreshData: handleManualRefresh,
    lastRefresh,
    isRefreshing,
    filterTasks,
    currentFilter,
  };
};