// Hook for managing certification expiry alerts and monitoring
// Requirements: 8.3

import { useState, useEffect, useCallback } from 'react';
import { workerApiService } from '../services/api/WorkerApiService';
import NotificationService from '../services/notifications/NotificationService';

interface CertificationAlert {
  certificationId: number;
  name: string;
  expiryDate: string;
  daysUntilExpiry: number;
  alertLevel: 'warning' | 'urgent' | 'expired';
}

interface UseCertificationAlertsReturn {
  alerts: CertificationAlert[];
  isLoading: boolean;
  error: string | null;
  refreshAlerts: () => Promise<void>;
  hasExpiredCertifications: boolean;
  hasUrgentAlerts: boolean;
  hasWarningAlerts: boolean;
  totalAlerts: number;
}

export const useCertificationAlerts = (): UseCertificationAlertsReturn => {
  const [alerts, setAlerts] = useState<CertificationAlert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadAlerts = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);

      const response = await workerApiService.getCertificationExpiryAlerts();
      
      if (response.success) {
        setAlerts(response.data);
        
        // Schedule notification reminders for certifications
        try {
          const certifications = response.data.map(alert => ({
            id: alert.certificationId,
            name: alert.name,
            expiryDate: alert.expiryDate,
            daysUntilExpiry: alert.daysUntilExpiry,
          }));
          
          await NotificationService.getInstance().scheduleCertificationExpiryReminders(certifications);
        } catch (notificationError) {
          console.warn('Failed to schedule certification reminders:', notificationError);
          // Don't fail the whole operation if notifications fail
        }
      } else {
        throw new Error(response.message || 'Failed to load certification alerts');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load alerts';
      setError(errorMessage);
      console.warn('Failed to load certification alerts:', errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshAlerts = useCallback(async () => {
    await loadAlerts();
  }, [loadAlerts]);

  useEffect(() => {
    loadAlerts();
  }, [loadAlerts]);

  // Computed properties for different alert levels
  const hasExpiredCertifications = alerts.some(alert => alert.alertLevel === 'expired');
  const hasUrgentAlerts = alerts.some(alert => alert.alertLevel === 'urgent');
  const hasWarningAlerts = alerts.some(alert => alert.alertLevel === 'warning');
  const totalAlerts = alerts.length;

  return {
    alerts,
    isLoading,
    error,
    refreshAlerts,
    hasExpiredCertifications,
    hasUrgentAlerts,
    hasWarningAlerts,
    totalAlerts,
  };
};

export default useCertificationAlerts;