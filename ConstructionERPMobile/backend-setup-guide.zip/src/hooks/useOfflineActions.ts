// Custom hook for offline-aware actions
// Provides methods that work both online and offline

import { useCallback } from 'react';
import { useOffline } from '../store/context/OfflineContext';
import { workerApiService } from '../services/api/WorkerApiService';
import { GeoLocation } from '../types';

export const useOfflineActions = () => {
  const { isOnline, queueAction } = useOffline();

  // Attendance actions
  const clockIn = useCallback(async (
    projectId: string,
    location: GeoLocation
  ) => {
    if (isOnline) {
      return await workerApiService.clockIn({ projectId, location });
    } else {
      await queueAction('CLOCK_IN', { projectId, location });
      return {
        success: true,
        data: {
          message: 'Clock in queued for sync when online',
        },
      };
    }
  }, [isOnline, queueAction]);

  const clockOut = useCallback(async (
    projectId: string,
    location: GeoLocation
  ) => {
    if (isOnline) {
      return await workerApiService.clockOut({ projectId, location });
    } else {
      await queueAction('CLOCK_OUT', { projectId, location });
      return {
        success: true,
        data: {
          message: 'Clock out queued for sync when online',
        },
      };
    }
  }, [isOnline, queueAction]);

  const startLunchBreak = useCallback(async (
    workerId: string,
    projectId: string
  ) => {
    if (isOnline) {
      return await workerApiService.startLunchBreak({ workerId, projectId });
    } else {
      await queueAction('START_LUNCH_BREAK', { workerId, projectId });
      return {
        success: true,
        data: {
          success: true,
          message: 'Lunch break start queued for sync when online',
          result: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const endLunchBreak = useCallback(async (
    workerId: string,
    overtimeInfo: any,
    overtimeType: 'START' | 'END' = 'END'
  ) => {
    if (isOnline) {
      return await workerApiService.sendOvertimeAlert({ workerId, overtimeInfo, overtimeType });
    } else {
      await queueAction('END_LUNCH_BREAK', { workerId, overtimeInfo, overtimeType });
      return {
        success: true,
        data: {
          success: true,
          message: 'Lunch break end queued for sync when online',
          result: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  // Task actions
  const startTask = useCallback(async (taskId: number, location: GeoLocation) => {
    if (isOnline) {
      return await workerApiService.startTask(taskId, location);
    } else {
      await queueAction('START_TASK', { taskId, location });
      return {
        success: true,
        data: {
          success: true,
          message: 'Task start queued for sync when online',
          task: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const updateTaskProgress = useCallback(async (
    taskId: number,
    progressPercent: number,
    description: string,
    location: GeoLocation
  ) => {
    if (isOnline) {
      return await workerApiService.updateTaskProgress(taskId, progressPercent, description, location);
    } else {
      await queueAction('UPDATE_TASK_PROGRESS', {
        taskId,
        progressPercent,
        description,
        location,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Task progress update queued for sync when online',
          task: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const completeTask = useCallback(async (taskId: number, location: GeoLocation) => {
    if (isOnline) {
      return await workerApiService.completeTask(taskId, location);
    } else {
      await queueAction('COMPLETE_TASK', { taskId, location });
      return {
        success: true,
        data: {
          success: true,
          message: 'Task completion queued for sync when online',
          task: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  // Report actions
  const createDailyReport = useCallback(async (reportData: {
    assignmentId: number;
    workDescription: string;
    startTime: Date;
    endTime: Date;
    progressPercent: number;
    issues: string[];
    notes: string;
    location: GeoLocation;
  }) => {
    if (isOnline) {
      return await workerApiService.createDailyReport(reportData);
    } else {
      await queueAction('SUBMIT_DAILY_REPORT', reportData);
      return {
        success: true,
        data: {
          success: true,
          message: 'Daily report queued for sync when online',
          report: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  // Request actions
  const submitLeaveRequest = useCallback(async (requestData: {
    title: string;
    description: string;
    startDate: Date;
    endDate: Date;
    leaveType: 'annual' | 'sick' | 'emergency' | 'medical';
  }) => {
    if (isOnline) {
      return await workerApiService.submitLeaveRequest(requestData);
    } else {
      await queueAction('SUBMIT_REQUEST', {
        requestType: 'leave',
        data: requestData,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Leave request queued for sync when online',
          request: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const submitMaterialRequest = useCallback(async (requestData: {
    title: string;
    description: string;
    items: Array<{
      name: string;
      quantity: number;
      unit: string;
      specifications?: string;
    }>;
    requiredDate: Date;
    priority: 'low' | 'medium' | 'high' | 'urgent';
  }) => {
    if (isOnline) {
      return await workerApiService.submitMaterialRequest(requestData);
    } else {
      await queueAction('SUBMIT_REQUEST', {
        requestType: 'material',
        data: requestData,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Material request queued for sync when online',
          request: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const submitToolRequest = useCallback(async (requestData: {
    title: string;
    description: string;
    tools: Array<{
      name: string;
      quantity: number;
      specifications?: string;
      duration?: string;
    }>;
    requiredDate: Date;
    priority: 'low' | 'medium' | 'high' | 'urgent';
  }) => {
    if (isOnline) {
      return await workerApiService.submitToolRequest(requestData);
    } else {
      await queueAction('SUBMIT_REQUEST', {
        requestType: 'tool',
        data: requestData,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Tool request queued for sync when online',
          request: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const submitReimbursementRequest = useCallback(async (requestData: {
    title: string;
    description: string;
    amount: number;
    category: string;
    expenseDate: Date;
    receiptAttachments: string[];
  }) => {
    if (isOnline) {
      return await workerApiService.submitReimbursementRequest(requestData);
    } else {
      await queueAction('SUBMIT_REQUEST', {
        requestType: 'reimbursement',
        data: requestData,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Reimbursement request queued for sync when online',
          request: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  const submitAdvancePaymentRequest = useCallback(async (requestData: {
    title: string;
    description: string;
    amount: number;
    reason: string;
    requiredDate: Date;
  }) => {
    if (isOnline) {
      return await workerApiService.submitAdvancePaymentRequest(requestData);
    } else {
      await queueAction('SUBMIT_REQUEST', {
        requestType: 'advance_payment',
        data: requestData,
      });
      return {
        success: true,
        data: {
          success: true,
          message: 'Advance payment request queued for sync when online',
          request: null,
        },
      };
    }
  }, [isOnline, queueAction]);

  return {
    // Attendance
    clockIn,
    clockOut,
    startLunchBreak,
    endLunchBreak,
    // Tasks
    startTask,
    updateTaskProgress,
    completeTask,
    // Reports
    createDailyReport,
    // Requests
    submitLeaveRequest,
    submitMaterialRequest,
    submitToolRequest,
    submitReimbursementRequest,
    submitAdvancePaymentRequest,
  };
};

export default useOfflineActions;