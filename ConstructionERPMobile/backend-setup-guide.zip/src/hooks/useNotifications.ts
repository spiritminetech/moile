import { useEffect, useState } from 'react';
import { useNotifications as useNotificationContext } from '../store/context/NotificationContext';
import { Notification, NotificationType } from '../types';
import { NotificationService } from '../services/notifications';

export interface UseNotificationsReturn {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
  error: string | null;
  markAsRead: (notificationId: number) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  removeNotification: (notificationId: number) => Promise<void>;
  clearNotifications: () => Promise<void>;
  loadNotifications: () => Promise<void>;
  scheduleLocalNotification: (title: string, body: string, data?: any) => Promise<string | null>;
  hasPermission: boolean;
  requestPermissions: () => Promise<boolean>;
  pushToken: string | null;
  refreshNotifications: () => Promise<void>;
}

export const useNotifications = (): UseNotificationsReturn => {
  const { state, actions } = useNotificationContext();
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [pushToken, setPushToken] = useState<string | null>(null);

  useEffect(() => {
    checkPermissions();
    loadPushToken();
    // Load notifications on mount
    actions.loadNotifications();
  }, []);

  const checkPermissions = async () => {
    try {
      const permissionStatus = await NotificationService.getInstance().requestPermissions();
      setHasPermission(permissionStatus.granted);
    } catch (error) {
      console.error('Error checking notification permissions:', error);
      setHasPermission(false);
    }
  };

  const loadPushToken = async () => {
    try {
      const token = NotificationService.getInstance().getPushToken() || await NotificationService.getInstance().getStoredPushToken();
      setPushToken(token);
    } catch (error) {
      console.error('Error loading push token:', error);
    }
  };

  const requestPermissions = async (): Promise<boolean> => {
    try {
      const permissionStatus = await NotificationService.getInstance().requestPermissions();
      setHasPermission(permissionStatus.granted);
      return permissionStatus.granted;
    } catch (error) {
      console.error('Error requesting notification permissions:', error);
      return false;
    }
  };

  const scheduleLocalNotification = async (
    title: string,
    body: string,
    data?: any
  ): Promise<string | null> => {
    try {
      return await NotificationService.getInstance().scheduleLocalNotification(title, body, data);
    } catch (error) {
      console.error('Error scheduling local notification:', error);
      return null;
    }
  };

  const refreshNotifications = async (): Promise<void> => {
    await actions.loadNotifications();
  };

  return {
    notifications: state.notifications,
    unreadCount: state.unreadCount,
    isLoading: state.isLoading,
    error: state.error,
    markAsRead: actions.markAsRead,
    markAllAsRead: actions.markAllAsRead,
    removeNotification: actions.removeNotification,
    clearNotifications: actions.clearNotifications,
    loadNotifications: actions.loadNotifications,
    scheduleLocalNotification,
    hasPermission,
    requestPermissions,
    pushToken,
    refreshNotifications,
  };
};

export default useNotifications;